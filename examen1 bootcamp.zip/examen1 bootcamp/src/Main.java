public class Main {
    public static void main(String[] args) {
// parte 1 del 1º examen de programación en bootcamp

        int respuesta;
        respuesta = suma(16, 35, 72);

        System.out.println(respuesta);

        Coche miCoche = new Coche();
        miCoche.numeroPuerta();
        miCoche.numeroPuerta();
        miCoche.numeroPuerta();

        System.out.println(miCoche.puerta);
    }
        static int suma(int a, int b, int c) {
            return a + b + c;
        }

    // parte 2 del 1º examen de programacion en bootcamp

    static class Coche{
        int puerta = 1;

        void numeroPuerta() {
            this.puerta++;
        }
    }

}